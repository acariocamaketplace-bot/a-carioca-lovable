<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# Estrela-guia

Cariocas economizam dinheiro de verdade nas lojas locais que já amam.

## Métrica

Pessoas que instalam o app a partir do site a cada mês
